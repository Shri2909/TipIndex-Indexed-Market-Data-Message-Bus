# tiplog

C++ Market-Data Message Bus with Indexed Replay, approved
[plan v1.1, Tier B](docs/plan/INDEX.md). **The Tier B core, P0–P8, is complete.**
Start with the [technical report](docs/report/REPORT.md) and the
[reproduction guide](docs/report/REPRODUCE.md). Detailed results are in
[results_tip.md](docs/report/results_tip.md) (P6 engine experiments) and
[results_layout.md](docs/report/results_layout.md) (P7 storage-layout optimizer).
Acceptance is recorded per phase, e.g. the [P6 gate](results/p6/phase-gate.json),
the [P7 gate](results/p7/phase-gate.json) and the final core gate
`results/p8/phase-gate.json`; [PROGRESS](docs/plan/PROGRESS.md) has the execution record.
P8 is the historical core acceptance. Audit remediation was approved on 2026-10-26;
the current corrections and validation are documented in
[REMEDIATION.md](docs/report/REMEDIATION.md). Saved P6/P7 timings describe the
pre-remediation source, not a fresh measurement of the corrected implementation.
Optional [work-budgeted replay/Tail polling](docs/report/POLL_BUDGET.md) was subsequently
approved and added as F-01, with separate validation and synthetic measurements.
Its [measured results](docs/report/POLL_BUDGET_RESULTS.md) show shorter polling turns
and the cost of repeated preparation; the feature remains opt-in.
The subsequent [independent audit and remediation](audit/independent-20261027T041900Z/REPORT.md)
records current-source validation separately. Earlier phase and feature gates
retain their historical source identities and measurements.
Tier C and roadmap extensions R1–R10
remain outside the approved implementation scope.

## Repository layout

The workspace's empty, managed `.git/` is read-only. Git metadata lives in the
writable `.tiplog-git/`, with this directory as its worktree. Use:

```bash
scripts/git.sh status --short
scripts/git.sh diff
```

The wrapper passes explicit `--git-dir` and `--work-tree` paths and works from
any current directory. Plain `git status` cannot discover this repository in
this managed workspace. Local source snapshots are recorded in PROGRESS. Build files, `.venv`,
local metadata, raw inputs, message-level traces and large raw results are ignored.

## Python setup

Phase 0 validated `/usr/bin/python3` (CPython 3.14.4) and an isolated `.venv`.
Recreate with a compatible explicit interpreter, then install the frozen package
versions (network access required on a fresh checkout):

```bash
/usr/bin/python3 -m venv .venv
PIP_CACHE_DIR="$PWD/build/pip-cache" .venv/bin/python -m pip install --require-hashes --only-binary=:all: -r py/requirements.txt
.venv/bin/python -m pip check
```

[requirements.txt](py/requirements.txt) is the complete installed project package
snapshot, now locked to verified wheel hashes for CPython 3.14 on Linux x86_64;
pytest is patched to 9.0.3. Pip itself is recorded in
[the historical interpreter manifest](results/env/p0-python.json).
Hypothesis and optional extensions are deferred. Set `MPLCONFIGDIR` to a writable
directory for standalone plotting; `check_all.sh` does this automatically.

## Build and check

Requires CMake ≥3.30, GNU Make, GCC and Clang with sanitizer runtimes. The
validated versions are saved in `results/env/`. All presets use Unix Makefiles:

```bash
scripts/check_all.sh
scripts/env_capture.sh > results/env/local.json
```

`check_all.sh` configures, builds and runs CTest for `debug`, `release`,
`asan-ubsan` and `fuzz`, then checks Python dependencies and runs package/script pytest regressions. It saves
exact arguments, exit codes and logs under a fresh `results/p0/<UTC timestamp>/`.
Set `CMAKE_BUILD_PARALLEL_LEVEL` to adjust parallel jobs (default 4).

```bash
cmake --preset release
cmake --build --preset release --parallel 4
ctest --preset release
```

The fuzz preset builds `fuzz_trace_reader`, `fuzz_itch_walker`, the
structure-aware `fuzz_engine_ops`, and `fuzz_poll_budget`. They link `tiplog::fuzzer_options`; normal tests retain
GoogleTest's main with `fuzzer-no-link`. Accepted P1 timed checks and exact
restart commands are recorded in [the fuzz execution notes](results/p1/fuzz-segmented-notes.md).
Sanitizer execution in this managed environment requires running outside sandbox
tracing while retaining leak detection; see the saved P0/P1 results.

Google Benchmark **v1.9.5** and GoogleTest **v1.17.0** use fixed commit
archives with SHA-256 verification by default. An unverified exact system
GoogleTest requires both `-DTIPLOG_ALLOW_SYSTEM_GTEST=ON` and
`-DTIPLOG_FORCE_FETCH_GTEST=OFF`. On this workspace the verified archives are cached in ignored
`build/downloads/`; a fresh checkout fetches them from upstream. The archive
path is selected with `-DTIPLOG_FORCE_FETCH_GTEST=ON`. Upstream licenses are
retained in dependency source trees; inspected revisions and primary references
are recorded in [the Phase 0 source ledger](docs/plan/RESEARCH.md#7-phase-0-just-in-time-source-inspection--2026-10-17).

Environment capture probes CPU affinity, topology, frequency and counter access;
it makes no privileged setting changes. The approved default uses wall/user/system
CPU time and, in later experiments, explicitly simulated Cachegrind results on
reduced cases. Phase 0 diagnostics establish no performance claim.

## P1 data tools

The approved source is the 2019-12-30 Nasdaq sample. Its identity, acquisition
metadata and gzip validation are in [data/manifest.json](data/manifest.json).
Raw input, real fuzz seeds and message-level traces stay in ignored local
directories. The intact gzip lacks a BinaryFILE terminator; metadata explicitly
retains `incomplete=true`. Protocol references and actual reading depth are in
[the Python ledger](results/p1/python-sources.md) and
[the independent C++ ledger](results/p1/cpp-sources.md).

The following commands reproduce the conversion and independent count paths
from an already acquired input. Complete production gate results, including
repeat conversion, are recorded separately in PROGRESS; these examples do not
assert an unexecuted check passed.

```bash
PYTHONPATH=py .venv/bin/python -m tiplog_py.itch convert data/raw/12302019.NASDAQ_ITCH50.gz \
  --output data/traces/itch_20191230_0930_1000_spec.mdt \
  --also-flat data/traces/itch_20191230_0930_1000_flat.mdt \
  --counts-output results/data/itch_20191230_counts.json --volumes-dir results/data \
  --start 09:30:00 --end 10:00:00
bash -o pipefail -c 'gzip -dc data/raw/12302019.NASDAQ_ITCH50.gz | build/release/tiplog_walk - --out results/data/itch_20191230_counts_cpp.json'
build/release/tiplog_trace_check data/traces/itch_20191230_0930_1000_spec.mdt
PYTHONPATH=py MPLCONFIGDIR="$PWD/build/matplotlib" .venv/bin/python -m tiplog_py.figures.build --all
```

Normal conversion checks the complete decompressed stream even after the window
ends. `--limit-bytes` is a limited throughput diagnostic and cannot certify
full-day totals or source completeness. The bounded Python and C++ parsers are
independent implementations of the original Nasdaq specifications. Trace v1 is
the project's own checked little-endian format; original ITCH payloads and source
order are preserved in both H-spec and H-flat.


## Engine, replay and P5 harnesses

The deterministic single-threaded implementation now includes the topic registry,
compiled exact/subtree subscriptions, bounded DATA/PAD ring, shared partition
index, four merge kernels and captured-range replay/Tail chaining. Public types
and entry points are in [engine.hpp](src/tiplog/engine/engine.hpp).
`open_replay` captures an exclusive upper bound. Positive full-budget batches
return More immediately; a later positive poll establishes completion. A completed
checkpoint advances past filtered events as well as delivered events. Tail polls
chain those checkpoints and can capture a newer head after catching up. Retention
failures are explicit, with a valid delivered prefix.

Output-only Scan, Indexed and Auto share the same progress/expiry semantics.
The optional `PollLimits` overloads cap traversal and report why a call stopped;
finite budgets can yield with no outputs and use different intermediate progress.
See the [polling contract and caller example](docs/report/POLL_BUDGET.md).
Thresholds are
configurable; P6 froze a training-selected benchmark policy of64 partitions and
candidate fraction1.0 before held-out evaluation. This does not change the
engine's configurable defaults or establish a universal optimum. Wide terms use
Scan. Delivered byte spans are non-owning views subject to the documented Engine
lifetime/publication rules. The implementation has no concurrent-reader or durable
storage guarantee.

`tiplog_sim --help` lists the deterministic trace-driver options. The accepted
[RC3 evidence](results/p5/rc3-evidence.md) saves exact real-trace and synthetic
commands for all modes/kernels, including successful and expired consumers.
The independent raw-path/full-history references are under `tests/ref/`.

P5 exposes the full M1/M1-touch and M2 matrices, with limited pilot execution
tracked separately in PROGRESS:

```bash
build/release/merge_bench --profile=pilot --verify-only --quad-padding-both
build/release/publish_bench --matrix --verify-only
.venv/bin/python scripts/run_p5_pilot.py
```

The first two commands perform functional checks without benchmark timing.
M1 uses the full selected output count and1GiB touch allocation; M2 verification
uses an explicitly reduced capacity. The final command prints the timing plan
only. Actual pilot execution requires the runner's saved quiescence declaration
and reviewed environment checks; [method](results/p5/pilot-method.md) explains the
exact boundaries and retained artifacts. The later authorized P6 campaigns,
noise accounting and held-out Auto evaluation are complete as recorded below.

## P6 results and regeneration

All1,028 microbenchmark configurations and41 recovery/memory workloads completed,
with820 measured process rounds and41 saved warm-ups. The final independent
saved-output audit passed10,295,181 checks. The report retains the4,320 expected
packed-limit rejections, one interrupted micro attempt and all noise flags.
It includes narrow-subscription gains, broad-subscription losses, publisher
maintenance cost and index memory/slack rather than a universal speedup claim.

With the accepted local raw results present, regenerate F01–F13 with:

```bash
PYTHONPATH=py MPLCONFIGDIR="$PWD/build/matplotlib" .venv/bin/python -m tiplog_py.figures.build --all
```

[Exact command/check records](results/p6/closeout-evidence.json),
[figure manifest](results/figures/p6-figures.json) and
[source-to-evidence map](results/p6/p6-report-source-map.md) make the result
auditable. Raw inputs/results remain local and ignored. The input still has
`incomplete=true`; measurements concern one laptop and one morning window,
with no hardware counters, durable storage or concurrent-reader guarantee.

## P7 storage-layout optimizer

`tiplog_layout` evaluates and optimizes how each symbol's topic tree is split into
stores under the declared M-store model: H-BASE (the old fixed rule), threshold
heuristics H-KM-min/max, Gray-code enumeration (ENUM) and the class-mask DP
(MASK-DP), plus a nonnegative global multiplier sweep. Costs are exact rationals
or checked integers, and all byte costs are **modeled**, not measured disk I/O.
MASK-DP matched ENUM on 10,000 random trees in release and ASan/UBSan, and the
article's worked example reproduces exactly. Exact coverage is complete for
workloads W1–W3 but not for W0 under the frozen solver caps.

```bash
build/release/tiplog_layout_cc5 --instances 10000 --seed 20191230 --output results/p7/cc5-release.json
build/release/tiplog_layout_example --output results/p7/worked-example.json
.venv/bin/python scripts/run_p7_studies.py --manifest results/p7/input-manifest.json --output results/raw/P7/studies --cpu 2
.venv/bin/python scripts/analyze_p7.py
```

The full study, global sweep, controlled runtime campaign (quiet machine only) and
gate checks are in [REPRODUCE.md](docs/report/REPRODUCE.md). The one-command figure
build above now regenerates F01–F18.

## P8 report and packaging

[REPORT.md](docs/report/REPORT.md) follows the plan's report outline and includes the
measured-number resume bullets; [REPRODUCE.md](docs/report/REPRODUCE.md) lists every
executed command, dependency, checksum, seed and local-data requirement. The closeout
checker `scripts/check_core_closeout.py` verifies the gate chain, dependency identities,
correctness evidence, document links and packaging, and writes an artifact manifest
(`results/p8/artifact-manifest.json`). Packaging is a local inventory only: nothing was
committed or pushed, and message-level Nasdaq data, real fuzz inputs and large raw
results stay in ignored local directories. **The original core execution stopped after P8.**
The subsequently approved audit remediation is recorded separately; use
the [current audit acceptance](audit/independent-20261027T041900Z/acceptance.json)
for the current closeout. `scripts/check_remediation.py` verifies its earlier
remediation freeze; source changes require separate current evidence.
