"""Accepted-attempt binding must survive retained retries and artifact damage."""
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('quiescence', ROOT / 'scripts/check_p7_runtime_quiescence.py')
quiescence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(quiescence)


def save(path, value):
    path.write_text(json.dumps(value))


def attempt(tmp_path):
    chosen = tmp_path / 'round-00-selected.process-audit.jsonl'
    chosen.write_text('selected process evidence\n')
    # Retained retries may have any lexical or filesystem iteration order.
    for name in ('000-old', 'zzz-old'):
        (tmp_path / f'round-00-{name}.process-audit.jsonl').write_text('other evidence\n')
    status = tmp_path / 'round-00-selected.status.json'
    accepted = dict(round=0, kind='warmup', status='passed', controls_validated=True,
                    launcher_pid=100, output=str(tmp_path/'round-00-selected.jsonl'),
                    settle={'started_utc': '2026-10-26T00:00:00+00:00',
                            'finished_utc': '2026-10-26T00:01:00+00:00'}, cpu3_idle_ratio=.99,
                    process_audit=str(chosen), artifact_identities={str(chosen): quiescence.sha(chosen)})
    save(status, accepted)
    save(tmp_path/'round-00.accepted.json', accepted)
    compact = {key: accepted[key] for key in ('round', 'kind', 'launcher_pid', 'output', 'settle', 'cpu3_idle_ratio')}
    compact.update(status_record=str(status), record_sha256=quiescence.sha(status))
    return compact, status, chosen


def test_explicit_accepted_attempt_wins_over_all_retry_names(tmp_path):
    compact, _, chosen = attempt(tmp_path)
    assert quiescence.accepted_process_audit(compact) == chosen


@pytest.mark.parametrize('damage', ['status', 'log', 'missing_log', 'acceptance', 'round', 'settle', 'cpu3'])
def test_changed_or_unbound_accepted_evidence_fails(tmp_path, damage):
    compact, status, chosen = attempt(tmp_path)
    if damage == 'status':
        status.write_text('{}')
    elif damage == 'log':
        chosen.write_text('modified')
    elif damage == 'missing_log':
        chosen.unlink()
    elif damage == 'acceptance':
        save(tmp_path/'round-00.accepted.json', {})
    elif damage == 'round':
        compact['round'] = 1
    elif damage == 'settle':
        compact['settle'] = dict(compact['settle'], finished_utc='2026-10-26T00:02:00+00:00')
    else:
        compact['cpu3_idle_ratio'] = 1.0
    with pytest.raises((ValueError, OSError)):
        quiescence.accepted_process_audit(compact)


def test_cli_failure_is_explicit_and_nonzero(tmp_path):
    destination = tmp_path/'result.json'
    assert quiescence.main(['--rule', str(tmp_path/'missing.json'), '--output', str(destination)]) == 1
    assert json.loads(destination.read_text())['status'] == 'failed'


def test_noise_is_read_from_accepted_log(tmp_path):
    compact, status, chosen = attempt(tmp_path)
    def sample(ticks):
        return {'processes': [dict(pid=77, ppid=1, cpu=2, user_ticks=ticks,
                                   system_ticks=0, comm='other-worker')]}
    chosen.write_text(json.dumps(sample(0))+'\n'+json.dumps(sample(1000))+'\n')
    document = json.loads(status.read_text())
    document['artifact_identities'][str(chosen)] = quiescence.sha(chosen)
    save(status, document)
    save(tmp_path/'round-00.accepted.json', document)
    compact['record_sha256'] = quiescence.sha(status)
    selected = quiescence.accepted_process_audit(compact)
    assert quiescence.foreign_cpu23_seconds(selected, compact['launcher_pid'], 100)[0] == 10
